// src/js/loot/generator.js
// Générateur de loot principal — orchestre les 3 couches RNG.

import { rollAffixes } from './affix-roller.js';
import { rollValue, applyIlvlMultiplier } from './value-roller.js';

/**
 * Génère un drop complet selon le contexte (biome, difficulté, magic find).
 *
 * @param {object} ctx - Contexte du drop
 *   @param {object} ctx.DATA - Toute la data chargée (weapons, armor, biomes, etc.)
 *   @param {string} ctx.biomeId - ID du biome courant
 *   @param {string} ctx.tier - "T1" à "T10" (difficulté)
 *   @param {number} [ctx.magicFind=0] - Bonus magic find en %
 *   @param {string} [ctx.forcedSlot] - Optionnel, force un slot précis
 * @returns {object|null} L'item drop, ou null si pas de drop
 */
export function generateLoot(ctx) {
  const { DATA, biomeId, tier, magicFind = 0, forcedSlot } = ctx;

  // === Couche 1 : Quoi drop ===
  const tierRoll = rollItemTier(DATA, magicFind);
  if (!tierRoll) return null;

  const biome = DATA.biomes[biomeId];
  const tierConfig = DATA.biomes ? DATA.forgeConfig.biomeDropMultipliers[tier] : { ilvl: 5 };
  const ilvl = tierConfig.ilvl;

  // Choix du type d'item (arme / armure / bijou)
  const itemType = forcedSlot || rollItemType(DATA, biome);
  const itemSubtype = rollItemSubtype(DATA, itemType, biome);

  // Spécial : si tier = legendary ou set, on tire dans la pool nommée
  if (tierRoll === 'legendary' && Math.random() < 0.7) {
    return rollLegendary(DATA, biome, ilvl);
  }
  if (tierRoll === 'set') {
    return rollSetPiece(DATA, biome, ilvl);
  }

  // === Couche 2 : Construire l'item de base ===
  const baseItem = buildBaseItem(DATA, itemType, itemSubtype, tierRoll, ilvl);
  if (!baseItem) return null;

  // === Couche 3 : Roll des affixes ===
  const affixCount = rollAffixCount(DATA, tierRoll);
  baseItem.affixes = rollAffixes(DATA, {
    item: baseItem,
    biome,
    tier: tierRoll,
    ilvl,
    count: affixCount,
  });

  // Si arme 2 mains, +1 affixe bonus
  if (baseItem.category === 'twoHand' && baseItem.affixes.length < affixCount + 1) {
    const extra = rollAffixes(DATA, {
      item: baseItem,
      biome,
      tier: tierRoll,
      ilvl,
      count: 1,
      excludeIds: baseItem.affixes.map(a => a.id),
    });
    baseItem.affixes.push(...extra);
  }

  return baseItem;
}

function rollItemTier(DATA, magicFind) {
  const config = DATA.forgeConfig.tierConfig;
  const roll = Math.random() * 100;
  const mfBonus = magicFind / 100;

  // Drop rates ajustés avec MF (les tiers rares montent)
  let cumul = 0;
  const adjusted = {
    common: config.common.dropRate * 100 * (1 - mfBonus * 0.5),
    magic: config.magic.dropRate * 100 * (1 + mfBonus * 0.5),
    rare: config.rare.dropRate * 100 * (1 + mfBonus * 0.8),
    epic: config.epic.dropRate * 100 * (1 + mfBonus * 1.2),
    legendary: config.legendary.dropRate * 100 * (1 + mfBonus * 1.5),
    set: config.set.dropRate * 100 * (1 + mfBonus * 1.5),
  };
  // Re-normalize
  const total = Object.values(adjusted).reduce((a, b) => a + b, 0);
  for (const k in adjusted) adjusted[k] = (adjusted[k] / total) * 100;

  for (const [tier, rate] of Object.entries(adjusted)) {
    cumul += rate;
    if (roll < cumul) return tier;
  }
  return 'common';
}

function rollItemType(DATA, biome) {
  // Distribution simple : 40% arme, 50% armure, 10% bijou
  const r = Math.random();
  if (r < 0.4) return 'weapon';
  if (r < 0.9) return 'armor';
  return 'jewelry';
}

function rollItemSubtype(DATA, itemType, biome) {
  if (itemType === 'weapon') {
    const allWeapons = [
      ...Object.keys(DATA.weapons.oneHand || {}),
      ...Object.keys(DATA.weapons.twoHand || {}),
      ...Object.keys(DATA.weapons.offHand || {}),
    ];
    // Bonus aux armes favorisées par le biome
    const favored = biome?.favoredImplicits || [];
    const weighted = allWeapons.map(w => ({
      id: w,
      weight: favored.includes(w) ? 2 : 1,
    }));
    return weightedRandom(weighted);
  }
  if (itemType === 'armor') {
    const slots = ['head', 'chest', 'legs', 'gloves', 'boots'];
    return slots[Math.floor(Math.random() * slots.length)];
  }
  if (itemType === 'jewelry') {
    return Math.random() < 0.5 ? 'amulet' : 'ring';
  }
}

function buildBaseItem(DATA, itemType, itemSubtype, tier, ilvl) {
  if (itemType === 'weapon') {
    let baseDef;
    let category;
    if (DATA.weapons.oneHand?.[itemSubtype]) {
      baseDef = DATA.weapons.oneHand[itemSubtype];
      category = 'oneHand';
    } else if (DATA.weapons.twoHand?.[itemSubtype]) {
      baseDef = DATA.weapons.twoHand[itemSubtype];
      category = 'twoHand';
    } else if (DATA.weapons.offHand?.[itemSubtype]) {
      baseDef = DATA.weapons.offHand[itemSubtype];
      category = 'offHand';
    }
    if (!baseDef) return null;

    // Roll de l'implicit (armes en ont 2-3 possibles)
    const implicits = baseDef.possibleImplicits || [];
    const implicit = implicits[Math.floor(Math.random() * implicits.length)];
    const implicitValue = rollValue(implicit.valueRange, applyIlvlMultiplier(DATA, ilvl));

    return {
      uid: generateUID(),
      type: itemType,
      subtype: itemSubtype,
      category,
      tier,
      ilvl,
      name: generateItemName(baseDef.name, tier),
      icon: baseDef.icon,
      tags: [...(baseDef.tags || [])],
      baseDamage: baseDef.baseDamage ? scaleRange(baseDef.baseDamage, applyIlvlMultiplier(DATA, ilvl)) : null,
      baseDamageType: baseDef.baseDamageType,
      implicit: { ...implicit, value: implicitValue },
      affixes: [],
      bonusAffixSlot: !!baseDef.bonusAffixSlot,
      uniqueModifier: null,
    };
  }

  if (itemType === 'armor') {
    const baseDef = DATA.armor[itemSubtype];
    if (!baseDef) return null;
    const implicit = baseDef.implicit;
    const implicitValue = rollValue(implicit.valueRange, applyIlvlMultiplier(DATA, ilvl));

    return {
      uid: generateUID(),
      type: itemType,
      subtype: itemSubtype,
      slot: itemSubtype,
      tier,
      ilvl,
      name: generateItemName(baseDef.name, tier),
      icon: baseDef.icon,
      tags: [...(baseDef.tags || [])],
      implicit: { ...implicit, value: implicitValue },
      affixes: [],
      uniqueModifier: null,
    };
  }

  if (itemType === 'jewelry') {
    // Pour amulette/bague, on tire dans le pool fixe
    const pool = itemSubtype === 'amulet' ? DATA.amulets : DATA.rings;
    const ids = Object.keys(pool).filter(k => k !== '_meta');
    const pickId = ids[Math.floor(Math.random() * ids.length)];
    const def = pool[pickId];

    return {
      uid: generateUID(),
      type: itemType,
      subtype: itemSubtype,
      slot: itemSubtype,
      tier,
      ilvl,
      name: def.name,
      icon: def.icon,
      tags: [...(def.tags || [])],
      grantedSpell: def.grantedSpell || null,
      spellDescription: def.spellDescription || null,
      uniquePassive: def.uniquePassive || null,
      passiveId: def.passiveId || null,
      affixes: [],
    };
  }

  return null;
}

function rollAffixCount(DATA, tier) {
  const config = DATA.forgeConfig.tierConfig[tier];
  if (!config) return 0;
  const [min, max] = config.affixCount;
  return min + Math.floor(Math.random() * (max - min + 1));
}

function rollLegendary(DATA, biome, ilvl) {
  // Choix d'un légendaire dans le pool, avec bonus aux légendaires du biome
  const legendaries = DATA.legendaries;
  const ids = Object.keys(legendaries).filter(k => k !== '_meta');
  const weighted = ids.map(id => ({
    id,
    weight: legendaries[id].biome === biome.id ? 3 : 1,
  }));
  const pickedId = weightedRandom(weighted);
  const def = legendaries[pickedId];

  // Construct item from legendary def + roll affixes
  const item = {
    uid: generateUID(),
    type: def.type,
    subtype: def.subtype,
    slot: def.slot || def.subtype,
    category: def.category,
    tier: 'legendary',
    ilvl,
    name: def.name,
    icon: def.icon,
    tags: [...(def.tags || [])],
    uniqueModifier: def.uniqueModifier,
    modifierId: def.modifierId,
    grantedSpell: def.grantedSpell || null,
    spellDescription: def.spellDescription || null,
    affixes: [],
    isLegendary: true,
  };

  // Roll 4 affixes pour les légendaires
  item.affixes = rollAffixes(DATA, {
    item,
    biome,
    tier: 'legendary',
    ilvl,
    count: 4,
    forcedAffixIds: def.guaranteedAffixes || [],
  });

  return item;
}

function rollSetPiece(DATA, biome, ilvl) {
  // Tire un set dont le biome est compatible (ou random)
  const sets = DATA.sets;
  const ids = Object.keys(sets).filter(k => k !== '_meta');
  const weighted = ids.map(id => ({
    id,
    weight: sets[id].biome === biome.id ? 3 : 1,
  }));
  const setId = weightedRandom(weighted);
  const set = sets[setId];

  // Tire une pièce du set
  const pieceIdx = Math.floor(Math.random() * set.pieces.length);
  const slots = ['head', 'chest', 'legs', 'gloves', 'boots'];
  const slot = slots[pieceIdx];
  const armorDef = DATA.armor[slot];

  const item = {
    uid: generateUID(),
    type: 'armor',
    subtype: slot,
    slot,
    tier: 'set',
    ilvl,
    name: `${armorDef.name} ${set.name}`,
    icon: armorDef.icon,
    tags: [...(armorDef.tags || []), ...(set.tags || [])],
    setId,
    setName: set.name,
    implicit: { ...armorDef.implicit, value: rollValue(armorDef.implicit.valueRange, applyIlvlMultiplier(DATA, ilvl)) },
    affixes: [],
    isSetPiece: true,
  };

  item.affixes = rollAffixes(DATA, {
    item,
    biome,
    tier: 'set',
    ilvl,
    count: rollAffixCount(DATA, 'set'),
  });

  return item;
}

// === Helpers ===

function rollValue(range, multiplier = 1) {
  const [min, max] = range;
  const val = min + Math.random() * (max - min);
  return Math.round(val * multiplier * 10) / 10;
}

function applyIlvlMultiplier(DATA, ilvl) {
  return DATA.forgeConfig.ilvlMultipliers[String(ilvl)] || 1;
}

function scaleRange(range, multiplier) {
  return [Math.round(range[0] * multiplier), Math.round(range[1] * multiplier)];
}

function generateItemName(baseName, tier) {
  // Pour le moment juste base + tier. On enrichira avec préfixe/suffixe selon affixes plus tard.
  return baseName;
}

function generateUID() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

function weightedRandom(items) {
  const total = items.reduce((s, i) => s + i.weight, 0);
  let r = Math.random() * total;
  for (const i of items) {
    r -= i.weight;
    if (r <= 0) return i.id;
  }
  return items[items.length - 1].id;
}
