# 📦 Livraison — Système d'itemisation v1

> Tous les fichiers du système de loot complet, prêts à intégrer dans ton repo.
> Calibré sur tes décisions : difficulté D2 modernisé, runs 10-15min, scaling ×50-80, drop modéré.

## 🎯 Comment intégrer dans ton repo

1. **Décompresse** ce dossier dans ton repo `dungeon-crawler`.
2. **Les fichiers** s'intègrent à la structure existante :
   - `docs/LOOT.md` → remplace l'ancien `docs/LOOT.md`
   - `src/data/*.json` → remplace les anciens / ajoute les nouveaux
   - `src/js/loot/*.js` → remplace les anciens / ajoute les nouveaux

3. **Pas de conflits attendus** avec le reste du code (ce sont de nouveaux fichiers ou des extensions).

4. **Charge les nouveaux JSON dans `src/js/data/loader.js`** :

```javascript
const FILES = [
  ['weapons', './src/data/weapons.json'],
  ['armor', './src/data/armor.json'],
  ['amulets', './src/data/amulets.json'],     // NOUVEAU
  ['rings', './src/data/rings.json'],         // NOUVEAU
  ['affixes', './src/data/affixes.json'],
  ['statuses', './src/data/statuses.json'],
  ['combos', './src/data/combos.json'],       // NOUVEAU
  ['sets', './src/data/sets.json'],           // NOUVEAU
  ['legendaries', './src/data/legendaries.json'], // NOUVEAU
  ['biomes', './src/data/biomes.json'],
  ['rooms', './src/data/rooms.json'],
  ['forgeConfig', './src/data/forge-config.json'], // NOUVEAU (ATTENTION: clé "forgeConfig" pas "forge-config")
];
```

5. **Test rapide** : ouvre `test-loot.html` (fourni à la racine de la livraison) dans ton navigateur servi par un HTTP local. Il génère 10 drops aléatoires pour vérifier que tout marche.

## 📁 Liste des fichiers

### Documentation
- `docs/LOOT.md` — Document de design complet et chiffré

### Data (JSON)
- `src/data/weapons.json` — Types d'armes avec implicits possibles
- `src/data/armor.json` — Armures avec implicits garantis
- `src/data/amulets.json` — Pool d'amulettes (chacune = 1 sort actif)
- `src/data/rings.json` — Pool de bagues (chacune = 1 passif unique)
- `src/data/affixes.json` — Pool d'affixes (préfixes + suffixes)
- `src/data/statuses.json` — Tous les statuts (DoT, CC, buffs)
- `src/data/combos.json` — Règles des combos élémentaires
- `src/data/sets.json` — 5 sets d'armure complets
- `src/data/legendaries.json` — 15 légendaires nommés
- `src/data/biomes.json` — 5 biomes avec tags favorisés
- `src/data/forge-config.json` — Configuration de la forge

### Code (JS modules)
- `src/js/loot/generator.js` — Générateur principal (3 couches RNG)
- `src/js/loot/affix-roller.js` — Roll des affixes selon tier/biome
- `src/js/loot/value-roller.js` — Roll des valeurs avec multiplicateurs
- `src/js/loot/forge.js` — Burn, reroll, transfer, upgrade
- `src/js/loot/synergies.js` — Calcul tags/sets/passifs équipés
- `src/js/loot/combo-resolver.js` — Détection combos en combat

### Test
- `test-loot.html` — Test rapide du générateur

## 🚀 Roadmap d'intégration recommandée

### Phase A — Intégration data (30 min)
- [ ] Copier tous les JSON dans `src/data/`
- [ ] Mettre à jour `loader.js` pour charger les nouveaux fichiers
- [ ] Vérifier qu'aucune erreur de chargement

### Phase B — Test du générateur (1h)
- [ ] Copier les 6 modules JS dans `src/js/loot/`
- [ ] Ouvrir `test-loot.html` et vérifier que les drops sortent
- [ ] Tester avec différents biomes et tiers de difficulté
- [ ] Vérifier que les affixes ont des qualités cohérentes

### Phase C — UI inventaire (2-3h)
- [ ] Créer un panneau d'inventaire qui liste les items
- [ ] Affichage d'un item avec : nom, tier (couleur), implicit, affixes (avec barres de qualité)
- [ ] Tooltip détaillé au survol
- [ ] Boutons : Équiper, Burn, Forge

### Phase D — Forge UI (2-3h)
- [ ] Modal forge avec les 5 opérations (Burn, Reroll Value, Reroll Affix, Transfer, Upgrade)
- [ ] Intégrer aux modules `forge.js`
- [ ] Affichage des coûts et confirmations

### Phase E — Combat integration (1-2h)
- [ ] Connecter `combo-resolver.js` aux dégâts en combat
- [ ] Connecter `synergies.js` aux calculs de stats du joueur
- [ ] Test des bonus de set en jeu

### Phase F — Polish
- [ ] Animation des drops (loot qui apparaît)
- [ ] Sons de drop selon tier
- [ ] Stockage localStorage du stash entre sessions

## ⚠️ Points d'attention

- **Le module `generator.js` attend que `DATA.forgeConfig` existe**. Vérifie que le loader transforme bien `forge-config.json` en clé `forgeConfig` (pas `forge-config`).
- **Pas de validation runtime** dans les modules : si un JSON est mal formé, ça crashera. Test soigneusement.
- **Les Légendaires sont fixes au lancement** (15 nommés). Si tu en ajoutes, ajoute juste une entrée dans `legendaries.json`.
- **Le système ne gère pas encore l'identification visuelle "qualité du roll"** dans l'UI. C'est à coder en Phase C.

## 💡 Idées d'extension future

- Affixes "tier interne" (T1 à T6 sur chaque affixe pour plus de variance D2-style)
- Legendaries procéduraux (un pool d'effets uniques que la machine combine)
- Trade entre joueurs (équilibrage à revoir)
- Hardcore mode
- Gemmes / runes
- Mode infini avec scaling

Bon dev !
