# 🗡️ Dungeon Crawler — RPG Tour par Tour

Un dungeon crawler tour par tour avec système de loot inspiré des ARPG (Diablo, PoE) et combat tactique inspiré de Divinity OS2 / Wasteland 3.

> **Concept clé** : pas de classe fixe. L'équipement définit le gameplay.

## 🎮 Tester le jeu

⚠️ Le jeu utilise des modules ES et fetch des JSON. Il **doit être servi par un serveur HTTP**, pas ouvert en `file://`.

### Méthode 1 — Python
```bash
cd dungeon-crawler
python3 -m http.server 8000
```
Puis http://localhost:8000

### Méthode 2 — Node
```bash
npx serve
```

### Méthode 3 — VSCode
Extension "Live Server" → clic droit `index.html` → Open with Live Server.

### Méthode 4 — Vercel
Push sur GitHub, connecte Vercel, c'est en ligne.

## 🛠️ Stack
- HTML / CSS / JS vanilla (modules ES)
- Data JSON
- Pas de build, pas de dépendance

## 📁 Structure
```
/src
  /js  /core /combat /entities /ai /grid /ui /loot /data
  /css /base /components
  /data  JSON
/docs
```

## 🚀 Workflow
1. `git checkout -b feature/X`
2. Modifier
3. Tester (serveur HTTP)
4. `git commit -m "feat: ..."`
5. PR

Conventions : `feat:` `fix:` `balance:` `refactor:` `docs:` `style:`

## 📖 Documentation
- [DESIGN.md](docs/DESIGN.md)
- [COMBAT.md](docs/COMBAT.md)
- [LOOT.md](docs/LOOT.md)
- [ROADMAP.md](docs/ROADMAP.md)
- [CHANGELOG.md](CHANGELOG.md)
